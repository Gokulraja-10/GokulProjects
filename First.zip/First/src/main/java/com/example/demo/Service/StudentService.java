package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.StudentEntity;
import com.example.demo.Repository.StudentRepo;

@Service
public class StudentService {
	@Autowired
	StudentRepo r;
	
	public StudentEntity saveDetails(StudentEntity student) {
		return r.save(student);
	}
	
	public List<StudentEntity> getAllDetails(){
		return r.findAll();
		
	}
	
	public String deleteData(Integer S_id) {
		r.deleteById(S_id);
		return "Successfully Deleted";
	}
	
	public StudentEntity updateData(Integer S_id, StudentEntity student) {
		student.setS_id(S_id);
		return r.save(student);
	}
}

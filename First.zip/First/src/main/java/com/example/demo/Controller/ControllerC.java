package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.StudentEntity;
import com.example.demo.Service.StudentService;

@RestController
@RequestMapping("/")
public class ControllerC {
	@Autowired
	StudentService s;
	
	@GetMapping("get")
	public List<StudentEntity> getDetails() {
		return s.getAllDetails();
	}
	@PostMapping("post")
	public StudentEntity postData(@RequestBody StudentEntity student) {
		return s.saveDetails(student);
	}
	@DeleteMapping("dlt/{S_id}")
	public String deleteData(@PathVariable Integer S_id) {
		return s.deleteData(S_id);
	}
	@PutMapping("up/{S_id}")
	public StudentEntity updateData(@PathVariable Integer S_id, @RequestBody StudentEntity Student) {
		return s.updateData(S_id, Student);

	}
}
